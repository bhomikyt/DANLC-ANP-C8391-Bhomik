a=int(input("Enter First Number: "))
b=int(input("Enter Second Number: "))
print("The addition of Two Numbers are: ",a+b)
print("The Subtraction of Two Numbers are: ",a-b)
print("The Multiplication of Two Numbers are: ",a*b)
print("The Division of Two Numbers are: ",a/b)
print("The Modulus of Two Numbers are: ",a%b)


