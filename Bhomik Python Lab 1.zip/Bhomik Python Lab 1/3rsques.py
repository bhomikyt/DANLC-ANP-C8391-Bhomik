e=int(input("Enter the Total Marks of a Student: "))
f=int(input("Enter the Marks: "))
print("The Percentage is: ",(f/e*100))