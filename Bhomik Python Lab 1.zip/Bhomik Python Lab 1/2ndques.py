c=int(input("Enter the Length of the Triangle: "))
d=int(input("Enter the Breath of the Triangle: "))
print("Area of The Triangle is: ",(1/2*c*d))