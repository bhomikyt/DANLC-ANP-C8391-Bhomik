# Write a Python program to count Uppercase, Lowercase, special character and numeric values in a given string
# Input = “Hell0 W0rld ! 123 * # welcome to pYtHoN”

string_user = "Hell0 W0rld ! 123 * # welcome to pYtHoN"
Uppercase = 0
Lowercase = 0
Special_Character = 0
Numeric_Value = 0

for char in string_user:
    if char.isupper():
        Uppercase += 1
    elif char.islower():
        Lowercase += 1
    elif char.isdigit():
        Numeric_Value +=1
    elif not char.isalnum():
        Special_Character +=1
    else:
        print("Invalid Syntax")
print(f"The Uppercase Character are : {Uppercase}")
print(f"The Lowercase Character are : {Lowercase}")
print(f"The Special Character are : {Special_Character}")
print(f"The Numeric Value are : {Numeric_Value}")

