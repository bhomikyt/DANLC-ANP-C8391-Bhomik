# Write a Python program to Count all letters,digits and special symbols from the given string:-
# Input = “P@#yn26at^&i5ve”

string_user = "P@#yn26at^&i5ve"
letters = 0
digits = 0
special_symbols = 0

for i in string_user:
    if i.isdigit():
        digits = digits + 1
    elif i.isalpha():
        letters = letters + 1
    elif not i.isalnum():
        special_symbols = special_symbols + 1
    else:
        print("Invalid Syntax")
print(f"The digits in strings are : {digits}")
print(f"The letters in strings are : {letters}")
print(f"The Special Symbols in strings are : {special_symbols}")