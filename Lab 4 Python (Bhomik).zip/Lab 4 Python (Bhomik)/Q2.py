# Q2 : wap to find the sum of first 10 natural numbers.
a=0
for i in range(1,11):
    a+=i
print(a)