# Q3. Wap to input  10 numbers from user and find their sum and average.
a=0
for i in range(1,11):
    num=int(input("Enter Number: "))
    a+=num
print("Sum of 10 Numbers are: ",a)
avg= a/10
print("The Average of 10 numbers are: ",avg)
