# Write a function in Python to count uppercase character in a text file “ABC.txt”

def count_uppercase(fileName):
    countUpper = 0
    try:
        with open(fileName, 'r') as file:
            for line in file:
                for char in line:
                    if char.isupper():
                        countUpper +=1
    except FileNotFoundError:
        print(f"The file {fileName} does not exist.")
    except Exception as e:
        print(f"An error occurred: {e}")
    return countUpper

fileName = input("Enter the file name: ")
count_uppercase(fileName)