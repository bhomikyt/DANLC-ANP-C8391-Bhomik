# Write a function in Python to count and display the total number of words in a text file “ABC.txt”
def count_words(fileName):
    length = 0
    try:
        with open(fileName, 'r') as file:
            for line in file:
                line = line.split()
                length += len(line)
    except FileNotFoundError:
        print(f"The file {fileName} does not exist.")
    except Exception as e:
        print(f"An error occurred: {e}")
    return length

fileName = input("Enter the file name: ")
count_words(fileName)