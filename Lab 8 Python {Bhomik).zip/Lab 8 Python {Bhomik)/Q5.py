# Wap to copy the contents of one file into another. input both file names with path from user

def copy_content(readFile, writeFile):
    try:
        with open(readFile, 'r') as rd, open(writeFile, 'w') as wt:
            for line in rd:
                wt.write(line)
        print(f"Content copied from {readFile} to {writeFile}")
    except FileNotFoundError:
        print(f"one of the file doesn't exist")
    except Exception as e:
        print(f"An error occurred: {e}")


readFile = input("Enter the file name whose data is to be copied")
writeFile = input("Enter the file name into which the data is to be copied.")
copy_content(readFile, writeFile)