# Wap to print all the Armstrong numbers between a given range
a = int(input("Enter the Starting Number : "))
b = int(input("Enter the Ending Number : "))
print(f"The armstrong number between {a} and {b} are : ", end=" ")

for i in range(a, b + 1):
    num = i
    Sum = 0
    while num > 0:
        Sum = Sum + ((num % 10) ** 3)
        num = num // 10
    if Sum == i:
        print(i, end=" ")

