# Wap to print first 10 prime numbers

prime_count = 0
i = 2
while prime_count < 10:
    j = 2
    count = 0
    while j < i:
        if i % j == 0:
            count = count + 1
        j = j + 1
    if count == 0:
        print(i)
        prime_count = prime_count + 1
    i = i +1