#3. Wap to check whether an year is leap or not.

year= int(input("Enter Year : "))
result="Leap Year" if year % 4 == 0 else "Not Leap Year"
print(result)