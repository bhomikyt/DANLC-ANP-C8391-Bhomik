#  wap to calculate the salary slip
#Basic  salary : input from user  // salary=60000,Da:2% of basic // da=0.02*salary,Ta:3% of salary, Hra:10% salary,PF:15% of salary,Total salary=basic+da+ta+hra+pf; Net salary = total-pf;
# Calculate bonus of employee to 25 % of salary by shift operators

a=int(input("Enter the Basic Salary :"))
da=0.02*a
ta=0.03*a
hra=0.1*a
pf=0.15*a

Total_salary = a + da + ta + hra + pf
Net_salary= Total_salary - pf
print("Net Salary",Net_salary)
print("Bonus",int(Net_salary)>>2)
