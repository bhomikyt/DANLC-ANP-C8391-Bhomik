#2.Wap to check whether a  character is in lower case or upper case.
ch= input("enter a character:")
print("character:",ch)
print("acii value" ,ord(ch))
#97 a z 122
#65 A Z 90
result= " character is in lower case" if ord(ch)>=97 and ord(ch)<=122 else "character is in  upper case" if ord(ch)>=65 and ord(ch)<=90 else "It is not an Aphabet"
print(result)