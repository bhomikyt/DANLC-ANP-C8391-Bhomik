#Wap to check whether a character is alphabet or not.
a=input("Enter a character:")
result= "It is an Alphabet" if ((ord(a)>=97 and ord(a)<=122) or (ord(a)>=65 and ord(a)<=90)) else "It is not an Alphabet"
print(result)