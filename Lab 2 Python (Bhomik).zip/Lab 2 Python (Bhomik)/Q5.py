#  Wap to check a character and print whether it is an alphabet, number or Special character
# Number 0- 9  : 48 to 57

char=input("Enter any character :")
result= "It is an Alphabet" if ((65<ord(char)<=90) or (97<=ord(char)<=122)) else "It is a number" if ((48<=ord(char)<=57)) else "It is Special Character"
print(result)