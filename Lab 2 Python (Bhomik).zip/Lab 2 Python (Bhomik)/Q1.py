#1.  Wap to check whether a number is negative or positive.

a= int(input("Enter a Number: "))
if a>=0:
    print("Number is Positive : )")
else:
    print("Number is Negative : (")