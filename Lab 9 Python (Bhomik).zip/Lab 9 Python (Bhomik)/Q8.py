"""Q8 Exception Handling in List Operations
Write a function `safe_list_access` that takes a list and an index as arguments and returns the element at that index.
Use exception handling to manage:
Index out of range.
Any other error (provide a generic error message).
Test the function with various lists and indices, including valid, negative, and out-of-range indices."""

def safe_list_access(li, index):
    try:
        if not (-len(li)<= index<len(li)):
            raise IndexError
        return li[index]
    except IndexError:
        print("Index out of range")
    except Exception as e:
        print(e)

li = ["is", 2, 7, 8.9]
print(safe_list_access(li, -3))