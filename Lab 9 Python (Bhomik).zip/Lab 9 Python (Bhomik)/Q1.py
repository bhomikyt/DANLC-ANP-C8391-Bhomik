 # Q1 Write a Python program to handle a ZeroDivisionError exception when dividing a number by zero.

First_Number = int(input("Enter the Ist Number : "))
Second_Number = int(input("Enter the IInd Number : "))
try:
    div = First_Number/Second_Number
    print("Division of number : ", div)
    print("Division of Two Numbers is Successfully Done")
except ZeroDivisionError:
    print("You Provide 0 in IInd Number : ", Second_Number)
    print("Can't Divide by O \n Try again!!")

