"""Q5 File Parsing with Detailed Error Handling
Write a function parse_file that reads a file containing numerical data (one number per line) and returns a list of these numbers. Use exception handling to manage:
File not found.
Permission denied.
Value errors (e.g., non-numeric data).
Provide detailed error messages indicating the line number and nature of the error.¶"""

def parse_file(fileName):
    try:
        with open(fileName, 'r') as file:
            content = file.read()
            if not content.isdigit():
                raise ValueError
            print(content)
    except FileNotFoundError:
        print(f"The file {fileName} does not exist.")
    except PermissionError:
        print(f"(Permission denied while accessing the {file}")
    except ValueError:
        print(f"A ValueError Occurred: Non-numeric Data")
    except Exception as e:
        print(f"An error occurred: {e}")

fileName = input("Enter the file name: ")
parse_file(fileName)