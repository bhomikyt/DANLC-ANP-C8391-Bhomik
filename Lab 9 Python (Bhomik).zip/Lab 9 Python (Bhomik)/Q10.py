"""Q10. Exception Handling with Logging
Write a function `read_and_log` that reads a file and logs any exceptions that occur to a separate log file.
Use exception handling to manage:
File not found.
Permission denied.
Any other error.
Ensure the function writes detailed error messages to the log file and test it with various scenarios."""

def convert_to_float(li):
    floats = []
    errors = []

    for s in li:
        try:
            floats.append(float(s))
        except ValueError as ve:
            errors.append((s, f"ValueError: {ve}"))
        except Exception as e:
            errors.append((s, f"Unexpected error: {e}"))

    return floats, errors


li = ["123.45", "hello", "456", "world", "78.9"]
floats, errors = convert_to_float(li)

print("Successfully converted floats:", floats)
print("Errors:")
for error in errors:
    print(error)
